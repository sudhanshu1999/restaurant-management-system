# Restaurant-Management-System
A restaurant management system based on PHP

Restaurant Management System was developed using PHP as backend and Bootstrap as frontend. The system allows the waiter to take orders/payments from customers and maintain table status. The cook can see the list of orders made by different waiters and notify the same once the food is prepared. The system allows the manager to see the monthly revenue of the restaurant and the inventory. The admin user can maintain the different roles of the system.

Credentials

Username: waiter

Password: 123



Username: cook

Password: 123



Username: host

Password: 123



Username: busboy

Password: 123



Note: includes/settings.inc.php has the DB connection settings.

oose.sql has the sample DB
