<!-- Login Modal Box -->
	<div class="modal fade" id="status">
	  <div class="modal-dialog w300">
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
			<h4 class="modal-title">Select table status</h4>
		  </div>
		  <div class="modal-body">
			  <div class="alert alert-danger" role="alert" id="changeDenied">You don't have the privilege to do this action</div>
			  <p class="radioStatus">
			  <input type="radio" name="status" value="green"><label>Open</label><br>
			  </p>
			  <p class="mt10"><button class="btn btn-success" id="tabSaveBoy">Save</button></p>
		  </div>
		</div>
	  </div>
	</div>